import * as d3 from d3.min.js

d3.json("https://cdn.jsdelivr.net/npm/us-atlas@3/states-10m.json")
    .then(function (us) {
        d3.json("datos.json")
            .then(function (datos) {
                // Lógica de burbuja de mapa
            })
    })
    .catch(function (error) {
        console.log(error);
    });
import * as muertes_por_opioides from muertes_por_opioides.json

