let appHeader = `
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="index.html" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <h2 class="m-0 text-primary" style="color:#0000;"><i class="icono_drogas"></i></h2>
    </a>
    <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="icono_drogas"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="index.html" class="nav-item nav-link"><strong>Inicio</strong></a>
            <a href="Sobrenosotros.html" class="nav-item nav-link"><strong>Sobre nosotros</strong></a>
            <a href="Tema_1.html" class="nav-item nav-link"><strong>Estadísticas de opioides</strong></a>
        </div>
    </div>
    </nav>
`;

document.getElementById("app-header").innerHTML = appHeader;

