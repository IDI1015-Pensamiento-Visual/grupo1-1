let appFooter = `
<div class="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s" style="margin-top: 7px;">
  <div class="text-center">
  </div>
</div>
`;

document.getElementById("app-Footer").innerHTML = appFooter;




