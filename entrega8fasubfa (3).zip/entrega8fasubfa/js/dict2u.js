var dict2u = '{"nombre": "Recetas en zonas urbanas", "fecha": ["2014", "2015", "2016", "2017", "2018", "2019", "2020"], "cantidad": ["928023", "950544", "977621", "1004670", "1033565", "1071752", "1104001", "1117120"]}'
export default dict2u;
