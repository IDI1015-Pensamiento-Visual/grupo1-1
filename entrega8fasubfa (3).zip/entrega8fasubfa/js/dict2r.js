var dict2r = '{"nombre": "Recetas en zonas rurales", "fecha": ["2014", "2015", "2016", "2017", "2018", "2019", "2020"], "cantidad": ["118501", "119725", "122039", "124298", "126760", "130457", "134054", "135604"]}'
export default dict2r;
