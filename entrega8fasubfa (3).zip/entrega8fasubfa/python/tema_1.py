from informacion_bd import info5
import json
import sys

# diccionario_5 = {}
# lista_anios = []
# lista_cantidad = []
# keys5 = ["nombre", "fecha", "cantidad"]

# for fila in info5:
#     anio = fila[8]
#     if fila[8] not in lista_anios:
#         lista_anios.append(anio)

# primer_elemento= lista_anios.pop(0)

# for anio in lista_anios:
#     cantidad = 0
#     for fila in info5:
#         if fila[8] == anio:
#             cantidad += 1
#     lista_cantidad.append(cantidad)
    
# values5 = ["Llamados de accidentes ocasionados por opioides", lista_anios, lista_cantidad]

# diccionario_5 = dict(zip(keys5, values5))

# print(diccionario_5)

# sys.stdout = open('dict5.js', 'w')
# my_json = json.dumps(diccionario_5)   
# #print("var jsonstr= '{}'".format(my_json))

# with open('dict5.js', 'w', encoding='utf-8') as f:
#     my_json = json.dumps(diccionario_5)   
#     f.write("var dict5 = '{}'".format(my_json))
    
    

#######################################3
lista5 = []
lista_cantidad = []
lista_anios = []

for fila in info5:
    anio = fila[8]
    if anio not in lista_anios:
        lista_anios.append(anio)

primer_anio = lista_anios.pop(0)

for anio in lista_anios:
    cantidad = 0
    for fila in info5:
        if fila[8] == anio:
            cantidad += 1
    lista_cantidad.append(cantidad)
        
for anio, cantidad in zip(lista_anios, lista_cantidad):
    dict5 = {}
    dict5["nombre"] = "Llamados de accidentes ocasionados por opioides"
    dict5["fecha"] = "01-01-"+str(anio)
    dict5["cantidad"] = cantidad
    lista5.append(dict5)

#print(lista5)

sys.stdout = open('dict5.js', 'w')
my_json = json.dumps(lista5)   

with open('dict5.js', 'w', encoding='utf-8') as f:
    my_json = json.dumps(lista5)   
    f.write("var jsonstr = '{}'".format(my_json))
    

    


