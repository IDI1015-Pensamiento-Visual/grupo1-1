import informacion_bd
import json
import sys


anos1= []
for fila in informacion_bd.info2:
    ano = fila[0]  
    if ano not in anos1:
        anos1.append(ano)
anos2 = anos1[1:-1]
anos = sorted(anos2)

recetasoverall1 = []
for dato in informacion_bd.info2:
    nombre = dato[1]
    if nombre == "National" and dato[6] == "Overall":
        recetasoverall1.append(dato[7])
recetasoverall = recetasoverall1[::-1]

recetasrurales1 = []
for dato in informacion_bd.info2:
    nombre = dato[1]
    if nombre == "National" and dato[6] == "Rural":
        recetasrurales1.append(dato[7])
recetasrurales = recetasrurales1[::-1]

recetasurbanas1 = []
for dato in informacion_bd.info2:
    nombre = dato[1]
    if nombre == "National" and dato[6] == "Urban":
        recetasurbanas1.append(dato[7])
recetasurbanas = recetasurbanas1[::-1]

diccionario2o = {}
diccionario2r = {}
diccionario2u = {}
keys2 = ["nombre", "fecha", "cantidad"]

values2o = ["Recetas totales", anos, recetasoverall]
values2r = ["Recetas en zonas rurales", anos, recetasrurales]
values2u = ["Recetas en zonas urbanas", anos, recetasurbanas]

diccionario2o = dict(zip(keys2, values2o))
diccionario2r = dict(zip(keys2, values2r))
diccionario2u = dict(zip(keys2, values2u))


sys.stdout = open('dict2o.js', 'w')
my_json = json.dumps(diccionario2o)   

with open('dict2o.js', 'w', encoding='utf-8') as f:
    my_json = json.dumps(diccionario2o)   
    f.write("var jsonstr = '{}'".format(my_json))

sys.stdout = open('dict2r.js', 'w')
my_json = json.dumps(diccionario2r)   

with open('dict2r.js', 'w', encoding='utf-8') as f:
    my_json = json.dumps(diccionario2r)   
    f.write("var jsonstr = '{}'".format(my_json))

sys.stdout = open('dict2u.js', 'w')
my_json = json.dumps(diccionario2u)   

with open('dict2u.js', 'w', encoding='utf-8') as f:
    my_json = json.dumps(diccionario2u)   
    f.write("var jsonstr = '{}'".format(my_json))