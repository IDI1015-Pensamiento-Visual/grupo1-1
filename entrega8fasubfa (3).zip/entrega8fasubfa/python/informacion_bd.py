import csv
import os


path2 = os.path.join("python","datos","Medicare_Part_D_Opioid_Prescribing_Rates.csv")

#path2 = "python\datos\Medicare_Part_D_Opioid_Prescribing_Rates.csv"

with open(path2, "r") as file:
    data2 = csv.reader(file) 
    info2 = []
    for row in data2:
        info2.append(row)


path3 = os.path.join("python","datos","Medicare_Part_D_Opioid_Prescribing_Rates.csv")

with open(path3) as file:
    data3 = csv.reader(file) 
    info3 = []
    for row in data3:
        info3.append(row)

path4 = "python\datos\VSRR_Provisional_Drug_Overdose_Death_Counts.csv"

with open(path4, "r") as file:
    data4 = csv.reader(file) 
    info4 = []
    for row in data4:
        info4.append(row)


path5 = "python\datos\Opioid_EMS_Calls.csv"

with open(path5, "r") as file:
    data5 = csv.reader(file) 
    info5 = []
    for row in data5:
        info5.append(row)
        
path6 = "python\datos\Overdosedata1.csv"

with open(path6, "r") as file:
    data6 = csv.reader(file) 
    info6 = []
    for row in data6:
        info6.append(row)
        
path7 = "python\\datos\\tablabarras.csv"

with open(path7, "r") as file:
    data7 = csv.reader(file) 
    info7 = []
    for row in data7:
        info7.append(row)

path8 = "python\\datos\\tablachica.csv"

with open(path8, "r") as file:
    data8 = csv.reader(file) 
    info8 = []
    for row in data8:
        info8.append(row)

path9 = "python\\datos\\tablalim.csv"

with open(path9, "r") as file:
    data9 = csv.reader(file) 
    info9 = []
    for row in data9:
        info9.append(row)

