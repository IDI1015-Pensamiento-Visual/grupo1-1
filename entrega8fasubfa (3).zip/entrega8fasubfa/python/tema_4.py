import informacion_bd
import json
import sys

anos=[]

for colum in informacion_bd.info6[0]:
    anos.append(colum)

anos_f = anos[1:-1]
#print(anos_f)

muertes_t = []

for dato in informacion_bd.info6[4]:
    muertes_t.append(dato)
muertes_t_f = muertes_t[1:-1]
#print(muertes_t_f)

muertes_m = []

for dato in informacion_bd.info6[5]:
    muertes_m.append(dato)
muertes_m_f = muertes_m[1:-1]

#print(muertes_m_f)

muertes_h = []

for dato in informacion_bd.info6[6]:
    muertes_h.append(dato)
muertes_h_f = muertes_h[1:-1]

#print(muertes_h_f)

diccionario_6t = {}
diccionario_6m = {}
diccionario_6h = {}
keys6 = ["nombre", "fecha", "cantidad"]

values6t = ["Muertes totales por opioides", anos_f, muertes_t_f]
values6m = ["Muertes por opioides en mujeres", anos_f, muertes_m_f]
values6h = ["Muertes por opioides en hombres", anos_f, muertes_h_f]

diccionario_6t = dict(zip(keys6, values6t))
diccionario_6m = dict(zip(keys6, values6m))
diccionario_6h = dict(zip(keys6, values6h))


sys.stdout = open('dict6t.js', 'w')
my_json6t = json.dumps(diccionario_6t)   


with open('dict6t.js', 'w', encoding='utf-8') as f:
    my_json6t = json.dumps(diccionario_6t)   
    f.write("var dict6t = '{}'".format(my_json6t))

sys.stdout = open('dict6m.js', 'w')
my_json6m = json.dumps(diccionario_6m)   

with open('dict6m.js', 'w', encoding='utf-8') as f:
    my_json6m = json.dumps(diccionario_6m)   
    f.write("var dict6m = '{}'".format(my_json6m))

sys.stdout = open('dict6h.js', 'w')
my_json6h = json.dumps(diccionario_6h)   

with open('dict6h.js', 'w', encoding='utf-8') as f:
    my_json6h = json.dumps(diccionario_6h)   
    f.write("var dict6h = '{}'".format(my_json6h))
    
