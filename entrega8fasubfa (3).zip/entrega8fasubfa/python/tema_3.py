import informacion_bd
import json
muertes_por_opioides = {}

# registrar el numero de muertes por opioides en cada estado
listaopioides = ["opioids","oxycodone","oxymorphone","hydrocodone","fentanyl","morphine","codeine","methadone","tramadol","buprenorphine"]

estados_l = []

for fila in informacion_bd.info4:
    estado = fila[8]
    causa = fila[4].lower()

    if estado != "State Name":
        if estado not in estados_l:
            estados_l.append(estado)
            muertes_por_opioides[estado] = 0

print(muertes_por_opioides)

for fila in informacion_bd.info4:
    estado = fila[8]
    causa = fila[4].lower()

    check = False
    for elem in listaopioides:
        if elem in causa:
            check = True

    print(check)

    if check == True:
        muertes_por_opioides[estado] += 1

print(muertes_por_opioides)
with open("muertes_por_opioides.json", "w") as archivo_json:
    json.dump(muertes_por_opioides, archivo_json)

#no se pq me estan sumando 570 los valores de muertes por opioides en todos los estados, cuando pueda filtro bien los datos#