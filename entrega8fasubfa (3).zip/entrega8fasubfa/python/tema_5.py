import informacion_bd
import json
import sys

anos1 = []

for colum in informacion_bd.info7[0]:
    anos1.append(colum)
anos = anos1[1:-1]

drogas1 = []
for droga in informacion_bd.info8:
    drogas1.append(droga[0])
drogas = drogas1[1:-1]

diccionario_8 = {}
muertes1 = []
for dato in informacion_bd.info9:
    muertes1.append(dato[2])
muertes = muertes1[1:-1]

nombre1 = []
for dato in informacion_bd.info9:
    nombre1.append(dato[1])
names = nombre1[1:-1]

fecha1 = []
for dato in informacion_bd.info9:
    fecha1.append(dato[0])
fechas = fecha1[1:-1]


keys8 = ["date", "name","value"]
values8 = [fechas, names, muertes]

diccionario_8 = dict(zip(keys8, values8))

sys.stdout = open('dict8.js', 'w')
my_json = json.dumps(diccionario_8)   


with open('dict8.js', 'w', encoding='utf-8') as f:
    my_json = json.dumps(diccionario_8)   
    f.write("var dict8 = '{}'".format(my_json))